Fully functional percentage calculator 
more summarized and easy to use values
open and unrestricted documentation